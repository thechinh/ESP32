## CUSTOM MODEL FOR BLETOOTH MESH
1. Using espidf sdk5
2. Folder for testing: ble_mesh-custom-sersor-model-code/examples
3. Client (send SET or GET message)
3. Server (send STATUS message)