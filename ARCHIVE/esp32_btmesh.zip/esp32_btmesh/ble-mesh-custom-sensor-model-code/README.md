# ESP32 BLE Mesh Custom Model 

:construction: WIP


**Note**: custom sensor client example uses SGP30 sensor lib as a component (not added here)


